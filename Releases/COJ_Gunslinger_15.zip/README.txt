CALL OF JUAREZ: GUNSLINGER - COMMUNITY PATCH 15 - CONSOLIDATION STABLE
======================================================================

STATUT
------
Build 15 de CONSOLIDATION construite DIRECTEMENT depuis la build 14 VALIDEE.

AUCUN changement fonctionnel n'est apporte par la 15 :
- CoJGunslinger.exe est byte-for-byte identique a la build 14 ;
- coj4/Data0.pak est byte-for-byte identique a la build 14 ;
- seul README.txt est consolide et corrige pour servir de hand-off propre.

La build 14 est validee en jeu et devient la base stable officielle du projet.
Elle inclut :
- le correctif Combo/Upgraded valide de la build 13 ;
- le correctif HudScoreBar Arcade de la build 14 lorsque FloatingScoreVis est
  regle sur Never/Off.

REGLE DE REPRISE : toute future build 16+ doit repartir de la 15 (binaries
identiques a la 14 stable), sauf raison technique documentee.

CORRECTIF VALIDE EN 14 : HUD SCORE ARCADE + OPTION OFF
------------------------------------------------
But : lorsque l'option d'affichage Combo/FloatingScoreVis est reglee sur
Never/Off (valeur retail 3), cacher aussi le HUD permanent des points Arcade
(HudScoreBar).

Methode chirurgicale EXE uniquement :
- classe ciblee : HudScoreBar ;
- routine ciblee : 0x00D75DE0 ;
- hook d'entree : 0x00D75DE0 -> wrapper .mod 0x033A4D00 ;
- le wrapper reproduit le prologue vanilla exact, puis lit :
      GameDI       = [0x02E65DB4]
      SettingsDI   = [GameDI + 0x28]
      FloatingScoreVis = [SettingsDI + 0x1C8]
- si FloatingScoreVis == 3 (Never/Off), le wrapper rejoint directement le
  chemin vanilla de masquage de HudScoreBar a 0x00D75E18 ;
- sinon il reprend le code vanilla a 0x00D75DFA sans autre changement.

Ce patch ne modifie PAS hud.xui et ne force pas Opacity/Show par XML. Il utilise
le propre chemin de masquage de HudScoreBar deja present dans l'EXE.

COMPORTEMENT VALIDE
-------------------
- Arcade + Always : HudScoreBar visible normalement.
- Arcade + Arcade only : HudScoreBar visible normalement.
- Arcade + Never/Off : HudScoreBar cache.
- Le correctif cartes/son de la build 13 reste strictement conserve.
- Duel, HudComboMessage, sous-titres et autres HUD ne sont pas touches.

CONTENU DU ZIP
--------------
Archive : COJ_Gunslinger_15.zip
- CoJGunslinger.exe
- coj4/Data0.pak
- README.txt

============================================================================
DOCUMENTATION CUMULATIVE DE LA BASE STABLE 15
============================================================================

============================================================================
1. CE QUE LE NOUVEL EXE ET DATA0 APPORTENT PAR RAPPORT A LA VERSION D'ORIGINE
============================================================================

REFERENCE D'ORIGINE
--------------------
Plateforme de reference : Steam x86 / 32-bit.
EXE Steam original SHA256 : ca1c4766900feb867372e0e2e87eb5adb92ca26ee537598a034ed7be1313d93c
Data0 original SHA256     : 0debd38c1560830486d8f7bdecf3806324e4f6357f1353ea0058b47bdfe8aa3b
Data0 original            : 1774 entrees.

EXE MODIFIE
-----------
Le nouvel EXE conserve l'integration Steam et ajoute/retient les fonctions
validees suivantes :

- ULC / DLC 235841 et 235842 actives.
- comportement CRC de demarrage de type GOG conserve ; les controles CRC de
  ressources modifies sont neutralises afin de charger le Data0 modifie.
- FOV horizontal natif ForcedHorzFov : plage projet 80-120, defaut patche a
  100 lorsqu'aucune valeur explicite n'est presente ; une ligne explicite dans
  Video.scr garde la priorite.
- application native des presets video sans forcer le jeu a oublier le preset
  choisi. Performance et Balanced restent leurs presets ; Quality devient le
  profil Quality+ du projet.
- profil Quality+ actuel : ShadowMapSize 4096, SpotShadowMapSize 4096,
  VisRange 10.0/10.0, AnisotropicTrilinear, FXFadeLevel 0.
- r_mesh_lod_force=0 et VisFactor=2.0 conserves.
- Weapon Trick : touche T remappable, route actuelle via l'action retail 18
  et interception du consommateur vers le predicate natif IdleTrick.
- Drop Weapon : touche G remappable, action native DROP_ITEM 62.
- option Auto Reload Weapons dans Options > Game, persistante dans le profil.
- option Hold Reload for Quick Reload, persistante ; implementation validee
  au clavier. Support equivalent gamepad toujours TODO.
- correctif build 13 Combo/Upgraded : le gate vanilla B1D0F0 est conserve ; uniquement
  l'appel cartes/son est filtre par la vraie option FloatingScoreVis selon la
  logique retail de mode de jeu. Valide en jeu dans la build 13.

Important : l'ancienne route MaxQuality / TrueMaxGraphics forcee n'est plus
utilisee. Elle faisait revenir le jeu sur Quality et ne doit pas etre remise.

Audit binaire EXE vs Steam retail :
- taille retail : 23197992 octets
- taille patch  : 23203840 octets
- octets differents/ajoutes : 12482
- zones de differences binaires : 92
- EntryPoint retail/patch : 0x02F192EE / 0x02F192EE
- SizeOfImage retail/patch: 0x02FA3000 / 0x02FA6000
- section additionnelle du patch : .mod, RVA 0x02FA3000, taille virtuelle 0x3000

DATA0 MODIFIE
-------------
Le Data0 garde exactement 1774 entrees et le meme ordre de fichiers que le
retail. Par rapport au Data0 original, 19 payloads/entrees
ont une difference de contenu ou de metadonnees :
  - data/settings/defaultvideoquality.scr
  - data/menu/scr/uigamemoviebackground.xui
  - data/menu/scr/menuvariablescheat.xui
  - data/menu/scr/menustartlevel.xui
  - data/menu/scr/menuskin.xui
  - data/menu/scr/menuprogresscheat.xui
  - data/menu/scr/menuinvokequickcheat.xui
  - data/menu/scr/menuinvokequeststate.xui
  - data/menu/scr/menuinvokecheat.xui
  - data/menu/scr/menudeveloperlist.xui
  - data/menu/scr/menudeveloperitems.xui
  - data/menu/scr/menucollectablecheat.xui
  - data/menu/scr/menucheat.xui
  - data/menu/scr/menuaidebug.xui
  - data/menu/hud/hud.xui
  - data/inventory.scr
  - data/inputs_keyboard.scr
  - data/inputs_def.scr
  - data/menu/movies/intromovies.scr

Role des modifications Data0 :

- data/inputs_keyboard.scr
  * Melee : E (retail F)
  * Use / Interact : F (retail E)
  * Objectif / Detective : TAB (retail O)
  * Skills : C (retail U)
  * Next Weapon : molette haut
  * Akimbo / weapon switch : molette bas
  * Throw Dynamite : bouton souris 3
  * Weapon Trick : T remappable, branche vers l'action retail utilisee par
    l'implementation EXE actuelle
  * Drop Weapon : G remappable

- data/inputs_def.scr
  * contient encore le symbole historique _ACTION_WEAPON_TRICK=29.
    AUDIT : aucune autre ressource lisible du Data0 ne le reference dans cette
    branche ; la route runtime validee ne l'utilise pas. Il est laisse en place
    dans 0.9.0 pour ne pas modifier une deuxieme ressource pendant ce gel.
    Un futur nettoyage peut le retirer dans un test isole.

- data/inventory.scr
  * Walker : AnimPrefix ColtWalker -> Sixshooter afin d'utiliser la famille
    d'animations compatible avec le Weapon Trick valide.

- data/menu/movies/intromovies.scr
  * Demo_Ending active comme film Attract ; le flux de demarrage conserve
    l'ecran Press to continue du projet.

- data/menu/scr/menuskin.xui + pages menu*cheat/developer
  * styles DevListButtonV / DevListBoxV / DevListBoxHtmlV ajoutes et utilises
    pour rendre les pages developer/debug coherentes et utilisables.

- data/settings/defaultvideoquality.scr + logique EXE
  * cette entree differe du retail au niveau archive/binaire et appartient a la
    branche historique des presets video. La logique finale validee est surtout
    portee par l'EXE native-apply : Performance et Balanced restent distincts,
    Quality devient le profil Quality+ documente plus haut. Ne pas retoucher
    cette entree seule sans A/B, car certaines ressources Data0 utilisent un
    stockage/compression que les outils ZIP generiques ne relisent pas proprement.

- data/menu/scr/uigamemoviebackground.xui
  * le groupe Subtitle est scale a 0.65 autour du pivot 640,720. Cette
    modification est presente dans la base actuelle et doit etre consideree lors
    de tout futur travail sur sous-titres/cinematiques.

- data/menu/hud/hud.xui
  * refonte HUD locale et chirurgicale detaillee ci-dessous.

EXTRACTION / LECTURE DE DATA0.PAK
---------------------------------
Data0 est un conteneur ZIP/Deflate avec des ressources ZipCrypto.

Cle / mot de passe utilise pendant le projet :
    TN2kTjNmBvn5axaS6tGY

Le snippet Python ci-dessous est un helper RE-TESTE pendant le projet. Il n'est
pas presente comme une copie verbatim d'un ancien message ; il reproduit la
methode utile avec la cle fournie et lit notamment hud.xui, inputs_keyboard.scr,
inputs_def.scr et inventory.scr :

    import zipfile
    from pathlib import Path

    PAK = Path("Data0.pak")
    OUT = Path("Data0_extracted")
    PASSWORD = b"TN2kTjNmBvn5axaS6tGY"

    OUT.mkdir(exist_ok=True)

    with zipfile.ZipFile(PAK, "r") as z:
        for info in z.infolist():
            try:
                z.extract(info, OUT, pwd=PASSWORD)
                print("[OK]", info.filename)
            except Exception as e:
                # Certaines entrees historiques ne sont pas relues proprement
                # par tous les outils ZIP generiques : ne pas conclure trop vite
                # que le PAK est corrompu.
                print("[SKIP]", info.filename, e)

Extraction ciblee, recommandee pour hud.xui :

    import zipfile

    PASSWORD = b"TN2kTjNmBvn5axaS6tGY"
    with zipfile.ZipFile("Data0.pak", "r") as z:
        data = z.read("data/menu/hud/hud.xui", pwd=PASSWORD)
        open("hud.xui", "wb").write(data)

REGLE DE REPACK : ne jamais reconstruire tout Data0 avec un zippeur generique.
Conserver les 1774 entrees et remplacer seulement la/les ressource(s) ciblee(s),
puis verifier decrypt/re-extract et identite byte-for-byte des autres payloads.

HUD ACTUEL PAR RAPPORT AU RETAIL
--------------------------------
Principes : canvas XUI natif 1280x720, corrections locales, pas de root-scale
global, et conservation des regles d'aspect lorsque necessaire.

Elements principaux actuellement modifies/validees :
- icone concentration HudCMGauge3 : position 55,55 ; scale 0.65.
- icone SOD haut-droite : position 1095,55 ; scale 0.65.
- vraie barre de boss HudEnemyHealthBar : 433,1.469948.
- bandeau objectif G_TaskUpdatedDI : Y=118, scale 0.75.
- munitions gauche/droite rapprochees des bords et rendues aspect-safe.
- chiffres munitions et separateurs reduits/nettoyes.
- noms d'armes : Y=596 ; conteneur gauche X=-144 ; conteneur droit X=745.6.
  Les gaps parent ammo<->nom sont exactement 24.000000 XUI des deux cotes.
- animation du nom gauche : miroir mathematique exact de l'animation droite :
  pour chaque keyframe correspondant, X_gauche = -X_droite.
  Aucun offset specifique au texte ou au nom d'arme n'est applique.
- score arcade et barre XP rapproches de l'origine bas-gauche.
- pose/accroupi deplace pour ne pas chevaucher les munitions droites.
- crosshair normal/akimbo/melee/dot/confuse reduits a 0.45.
- selecteur d'items reduit et legerement abaisse.
- messages flottants/score reduits ; T_Info a ete recale sur son fond afin
  d'eviter le decalage visible pendant l'animation.
- messages [F] / actions screen-space : parent HudTriggerInfo scale 0.60.
- tutoriel/alerte jaune : HudTutorial scale 0.65, position 104,620.
- Level Up : les transforms experimentaux responsables du message casse ont
  ete retires ; G_LevelUpDI et son parent G_Center sont revenus aux valeurs
  retail dans la branche actuelle.
- duel VITESSE/FOCALISATION : FOCALISATION X=556.573557 afin d'obtenir une
  marge exterieure droite egale mathematiquement a la marge gauche de VITESSE.
- duel : comportement visuel valide dans les tests recents ; ne pas normaliser
  aveuglement les quelques differences XUI restantes sans nouveau test.
- message normal [R] RECHARGER : HudReloadNotify est revenu EXACTEMENT a son
  sous-arbre XUI retail. Il est donc plus gros, mais ne se chevauche plus.
  Les essais R05/R06/R07 de scaling/recentrage ont ete retires.

AUDIT SEMANTIQUE HUD VS RETAIL
------------------------------
Nombre d'instances XUI portant un Id dans les deux versions : 876 (485 Id distincts).
Instances dont Properties et/ou Timelines different du retail : 64.
Liste exhaustive des instances differentes :
  - G_Outer #0: Scale: None -> '0.600000,0.600000,1.000000'
  - G_MainInfo #0: TIMELINE modifiee
  - T_Info #0: Position: '103.460609,103.359901,0.000000' -> '118.460609,103.359901,0.000000'
  - G_Group #1: Pivot: '83.999992,19.999994,0.000000' -> '84.000000,20.000000,0.000000'; Scale: '1.500000,1.500000,1.000000' -> '1.000000,1.000000,1.000000'
  - G_CritGroup #0: Pivot: '149.999939,99.999985,0.000000' -> '150.000000,100.000000,0.000000'; Scale: None -> '0.600000,0.600000,1.000000'
  - T_Combo #0: Scale: '1.200000,1.200000,1.000000' -> '1.000000,1.000000,1.000000'
  - G_Group #2: Pivot: None -> '0.000000,67.000000,0.000000'; Scale: None -> '0.700000,0.700000,1.000000'
  - G_Inner #6: Pivot: None -> '170.500000,0.000000,0.000000'; Scale: None -> '0.700000,0.700000,1.000000'
  - G_Akimbo #0: Pivot: None -> '2.000000,2.000000,0.000000'; Scale: None -> '0.450000,0.450000,1.000000'
  - G_Normal #0: Pivot: None -> '2.000000,2.000000,0.000000'; Scale: None -> '0.450000,0.450000,1.000000'
  - G_Melee #0: Pivot: None -> '2.000000,2.000000,0.000000'; Scale: None -> '0.450000,0.450000,1.000000'
  - G_Confuse #0: Pivot: None -> '2.000000,2.000000,0.000000'; Scale: None -> '0.450000,0.450000,1.000000'
  - G_Dot #0: Pivot: None -> '2.000000,2.000000,0.000000'; Scale: None -> '0.450000,0.450000,1.000000'
  - G_NewCollectable #0: Pivot: '128.999939,-0.000019,0.000000' -> '129.000000,34.000000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - G_TaskUpdatedDI #0: Pivot: None -> '196.000000,65.500000,0.000000'; Position: '0.000000,20.000000,0.000000' -> '0.000000,118.000000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - G_SpecialItem #0: Pivot: None -> '150.000000,50.000000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - HudTutorial #0: Pivot: None -> '247.000000,59.000000,0.000000'; Position: '393.000061,522.000000,0.000000' -> '104.000000,620.000000,0.000000'; Scale: None -> '0.650000,0.650000,1.000000'
  - G_ComboCounter #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'
  - T_Number #0: Scale: '1.500000,1.500000,1.000000' -> '1.000000,1.000000,1.000000'
  - HudCMGauge3 #0: Position: '95.000015,69.000008,0.000000' -> '55.000000,55.000000,0.000000'; Scale: '0.860000,0.860000,1.000000' -> '0.650000,0.650000,1.000000'
  - HudScoreBar #0: Pivot: None -> '0.000000,84.142006,0.000000'; Position: '78.570679,500.159729,0.000000' -> '18.000000,500.000000,0.000000'; Scale: None -> '0.800000,0.800000,1.000000'
  - HudSOD #0: Position: '1013.000000,57.000000,0.000000' -> '1095.000000,55.000000,0.000000'; Scale: '0.850000,0.850000,1.000000' -> '0.650000,0.650000,1.000000'
  - HudEnemyHealthBar #0: Position: '458.250000,44.469948,0.000000' -> '433.000000,1.469948,0.000000'
  - G_Group #15: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'; Scale: '1.250000,1.250000,1.000000' -> '0.900000,0.900000,1.000000'
  - T_Text #18: Scale: '1.200000,1.200000,1.000000' -> '1.000000,1.000000,1.000000'
  - HudItemSelect #0: Pivot: None -> '225.000000,150.000000,0.000000'; Position: '423.000000,372.000000,0.000000' -> '423.000000,392.000000,0.000000'; Scale: None -> '0.650000,0.650000,1.000000'
  - G_GunNameRight #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'; Position: '712.000000,529.000000,0.000000' -> '745.600000,596.000000,0.000000'
  - G_GunNameLeft #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'; Position: '74.000000,529.000000,0.000000' -> '-144.000000,596.000000,0.000000'; TIMELINE modifiee
  - G_AmmoRight #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'; KeepEdgeMode: None -> '2'; KeepPosY: None -> 'true'; Position: '724.000000,490.000000,0.000000' -> '872.000000,580.000000,0.000000'
  - G_CurrAmmo0 #0: Scale: '1.300000,1.400000,1.000000' -> '1.000000,1.000000,1.000000'
  - G_CurrAmmo1 #0: Scale: '1.300000,1.400000,1.000000' -> '1.000000,1.000000,1.000000'
  - T_Separator #0: PointSize: '24.000000' -> '18.000000'
  - G_InvAmmo0 #0: Scale: None -> '0.800000,0.800000,1.000000'
  - G_InvAmmo1 #0: Scale: None -> '0.800000,0.800000,1.000000'
  - G_InvAmmo2 #0: Scale: None -> '0.800000,0.800000,1.000000'
  - G_AmmoLeft #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'; KeepEdgeMode: None -> '2'; KeepPosY: None -> 'true'; Position: '28.000000,490.000000,0.000000' -> '-248.000000,580.000000,0.000000'
  - G_CurrAmmo0 #1: Scale: '1.300000,1.400000,1.000000' -> '1.000000,1.000000,1.000000'
  - G_CurrAmmo1 #1: Scale: '1.300000,1.400000,1.000000' -> '1.000000,1.000000,1.000000'
  - T_Separator #1: PointSize: '24.000000' -> '18.000000'
  - G_InvAmmo0 #1: Scale: None -> '0.800000,0.800000,1.000000'
  - G_InvAmmo1 #1: Scale: None -> '0.800000,0.800000,1.000000'
  - G_InvAmmo2 #1: Scale: None -> '0.800000,0.800000,1.000000'
  - G_Dynamite #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'
  - T_SeparatorSH #0: PointSize: '24.000000' -> '18.000000'
  - G_DynamiteCnt #0: Scale: '1.300000,1.300000,1.000000' -> '1.000000,1.000000,1.000000'
  - G_Inner #10: Pivot: '-0.000002,-0.000015,0.000000' -> '360.000000,360.000000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - G_Inner #11: Pivot: '-0.000002,-0.000015,0.000000' -> '640.000000,720.000000,0.000000'; Scale: None -> '0.650000,0.650000,1.000000'
  - T_Qte #0: Pivot: None -> '73.500000,18.000000,0.000000'; Scale: None -> '0.800000,0.800000,1.000000'
  - I_Crosshair #0: Scale: '10.000000,10.000000,1.000000' -> None
  - G_Reticule #0: Pivot: None -> '32.000000,32.000000,0.000000'
  - G_SlomoTime #0: Position: '614.000000,495.999939,0.000000' -> '556.573557,495.999939,0.000000'
  - T_Boss #0: Pivot: None -> '550.872559,75.857430,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - T_Boss1 #0: Pivot: None -> '550.872559,75.857430,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - T_Boss2 #0: Pivot: None -> '550.872559,75.857430,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - G_Group #16: Pivot: None -> '175.000000,18.500000,0.000000'; Scale: None -> '0.600000,0.600000,1.000000'
  - G_Inner #13: Pivot: None -> '260.000000,84.500000,0.000000'; Scale: None -> '0.700000,0.700000,1.000000'
  - HudRethrow #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'
  - T_Text #21: Pivot: None -> '247.000000,18.500000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'
  - HudPoseIndicator #0: Position: '1117.000000,579.000000,0.000000' -> '1145.000000,540.000000,0.000000'
  - G_Inner #14: Pivot: '-0.000118,-0.000013,0.000000' -> '66.000000,67.000000,0.000000'; Scale: None -> '0.700000,0.700000,1.000000'
  - HudXpBar #0: Position: '43.666656,532.024048,0.000000' -> '18.000000,500.000000,0.000000'
  - G_Group #18: Pivot: None -> '0.000000,60.000000,0.000000'; Scale: None -> '0.700000,0.700000,1.000000'
  - HudGatling #0: HoldAspectPivotPosition: None -> 'true'; HoldAspectRatio: None -> 'true'; HoldAspectRatioX: None -> 'true'
  - T_Text #22: Pivot: None -> '247.000000,18.500000,0.000000'; Scale: None -> '0.750000,0.750000,1.000000'


============================================================================
2. CE QU'ON FAIT QUI MARCHE - HAND-OFF POUR QUELQU'UN QUI PREND LA RELEVE
============================================================================

BASE A CONSERVER
----------------
Cette archive est la nouvelle base de reprise. Ne pas repartir d'un vieux
V11Zxx/R0x pour une nouvelle modification sans raison precise.

FONCTIONS VALIDEES / A GELER PAR DEFAUT
---------------------------------------
- Steam conserve + ULC 235841/235842.
- CRC ressources modifies pris en charge par l'EXE.
- ForcedHorzFov natif et defaut 100.
- presets Performance/Balanced/Quality+ avec methode native-apply persistante.
- Weapon Trick clavier T + Walker compatible.
- Drop Weapon G natif/remappable.
- Auto Reload Weapons et persistance.
- Hold Reload for Quick Reload au clavier + persistance.
- menu developer/debug et ses styles DevList.
- intro/attract actuel.
- HUD : top icons, vraie barre boss, objectifs, ammo, XP/score, pose,
  floating score, actions [F], tutoriels, Level Up, duel et noms d'armes dans
  l'etat documente ci-dessus.
- noms d'armes : NE PAS corriger les glyphes/texte individuellement. La seule
  logique retenue est conteneurs + animation miroir mathematique.

POINTS A RETESTER OU A FINIR
----------------------------
- normal [R] RECHARGER : la version actuelle est volontairement retail-exacte.
  Si on veut la reduire, il faut d'abord identifier le vrai transform/runtime
  qui controle le rendu final au lieu de re-scaler HudReloadNotify au hasard.
- option Affichage combo / partie Upgraded : RESOLUE et validee en build 13.
  Le gate vanilla B1D0F0 reste intact ; seul l'appel B1B562 -> B1BD60 est
  filtre avec la logique retail FloatingScoreVis + mode runtime.
  Comportement vanilla conserve : Story normal sans cartes, Story NG+ avec
  cartes, Arcade avec cartes lorsque l'option les autorise.
- HudScoreBar Arcade + FloatingScoreVis Never/Off : RESOLU et valide en build
  14 via le chemin vanilla Hide de HudScoreBar.
- QTE/reload minigame : la branche garde un G_Inner centre/pivote et scale 0.75 ;
  a valider explicitement sur plusieurs occurrences avant de le declarer final.
- gamepad Hold Reload / Quick Reload : TODO.
- rares variantes HUD : Gatling, Rethrow, WeaponSwap, Achievement progress,
  collectables/speciaux, QTE caches : les transforms existent dans la branche
  mais n'ont pas tous ete revalides autant que le HUD principal.
- 4:3, 16:10 et 21:9 : logique aspect-safe ajoutee sur plusieurs groupes, mais
  validation live complete encore souhaitable.
- CPU eleve avant la premiere entree : existe deja en vanilla ; traiter comme
  bug moteur, pas comme regression du patch.
- rafraichissement immediat de Borders ON : ancien TODO, non resolu.

REGLE DE TRAVAIL POUR LA SUITE
------------------------------
1. une seule famille/systeme par build de test ;
2. modifier le parent/transform identifie plutot que les glyphes enfants ;
3. comparer au vrai Data0 retail avant et apres ;
4. tester en jeu ;
5. seulement ensuite garder le changement dans la base suivante.


============================================================================
3. NOTES TECHNIQUES IMPORTANTES
============================================================================

PAK / CHIFFREMENT
-----------------
- Data0 est un ZIP/PAK de 1774 entrees.
- hud.xui est ZipCrypto + Deflate.
- mot de passe utilise par les ressources chiffrees de cette branche :
  TN2kTjNmBvn5axaS6tGY
- ne jamais reconstruire tout le PAK avec un zippeur generique.
- remplacer uniquement l'entree cible et conserver byte-for-byte les autres
  payloads chiffres.
- verifier apres chaque build : count=1774, ordre/noms identiques, decrypt
  round-trip, XML valide et nombre de payloads changes attendu.
- ATTENTION : plusieurs centaines d'entrees du Data0 retail lui-meme ne se
  decompriment pas correctement avec Python zipfile / un unzip generique. Ce
  n'est donc PAS un critere suffisant de corruption. Pour un audit global,
  comparer aussi ordre, headers centraux, CRC/tailles et payloads bruts ; pour
  hud.xui, le decrypt/re-extract cible reste un controle valide.

XML / XUI
---------
- NE PAS reserialiser hud.xui avec ElementTree/outil XML global pour produire le
  fichier final : cela avait modifie massivement le fichier et provoque des
  crashes dans les premieres Z39/Z41.
- faire des remplacements bytes cibles sur le plaintext original de la base.
- conserver CRLF et l'encodage.
- le repere de conception HUD est 1280x720.
- une egalite mathematique de conteneurs ne garantit pas une egalite optique des
  glyphes. Sauf demande explicite, preferer corriger les parents et animations,
  pas le contenu texte.

RELOAD NORMAL
-------------
- HudReloadNotify est retail-exact dans la base stable actuelle (heritage 0.9.0/0.9.2).
- les precedents essais de scale sur HudReloadNotify ou son G_Group changeaient
  taille/position mais n'ont pas corrige proprement le rendu souhaite.
- conclusion de hand-off : chercher le controleur/setter runtime qui compose ou
  transforme le prompt final avant toute nouvelle modification XUI.

NOMS D'ARMES
------------
- G_GunNameLeft  = -144.000000,596.000000,0
- G_GunNameRight =  745.600000,596.000000,0
- gap parent gauche = 24.000000 XUI
- gap parent droit  = 24.000000 XUI
- animation droite (X) : +150 -> 0 -> -12 -> -200
- animation gauche (X) : -150 -> 0 -> +12 -> +200
- relation imposee : X_gauche(t) = -X_droite(t)
- ne pas appliquer de compensation liee a SIX-SHOOTER/RANGER/etc. : les mots
  ont des metriques differentes et ces corrections cassent les autres armes.

DUEL
----
- placement VITESSE/FOCALISATION valide visuellement.
- plusieurs anciens essais de reticule ont ete retires.
- l'audit retail montre encore des differences XUI du duel (notamment pivot de
  G_Reticule et Scale retail de I_Crosshair). Comme le comportement actuel est
  valide en jeu, ne pas les 'nettoyer' sans A/B dedie : elles peuvent faire
  partie du chemin qui produit justement le rendu correct actuel.

LEFTOVERS / POINTS D'AUDIT CONNUS
---------------------------------
- inputs_def.scr contient encore _ACTION_WEAPON_TRICK=29, symbole historique
  non reference par les ressources lisibles de cette branche et non utilise par
  la route Weapon Trick actuelle. Laisser pour cette base ; nettoyage seulement
  dans un build isole avec test des controles.
- aucun ancien Scale de HudReloadNotify R05/R06/R07 n'est present.
- aucun decalage parent gauche -152 XUI de R08 n'est present.
- aucun offset texte specifique aux noms d'armes R06/R07 n'est present.
- G_LevelUpDI/G_Center ont ete compares au retail et les transforms fautifs ont
  ete retires.
- OBJECTIVE_LOCATION_PERSISTENT et G_Trigger_Take ont ete verifies retail-exacts
  lors de l'audit de la branche.

BRANCHES / METHODES A NE PAS REINTRODUIRE SANS RAISON
-----------------------------------------------------
- ancien Weapon Trick action-29 experimental comme chemin runtime ;
- anciens probes PlayerDI / raw XInput pour Hold Reload gamepad ;
- diagnostics CPU V11Z7/Z8/Z9/Z11/Z12/Z13/Z14 ;
- anciens essais Borders V11Z18/V11Z19 ;
- MaxQuality / TrueMaxGraphics force global ;
- root-scaling HUD global des branches rejetees ;
- premiere Z39 et premiere Z41 : repacks corrompus/non conformes, a ne jamais
  reutiliser comme base.
- 0.9.1 Combo/Upgraded visibility probe : REJETE. Il modifiait la logique de
  gate et rendait la competence/logique Upgraded disponible des le debut.
- 0.9.3 Combo/Upgraded widget-bit probe : REJETE. Il testait [ESI+0x20] bit 0 ;
  en live, les cartes/son ne fonctionnaient plus du tout. Ce bit n'est pas la
  valeur FloatingScoreVis et ne doit plus servir de proxy pour cette option.
- 0.9.4 repart strictement de 0.9.2 et ne reutilise aucun octet de 0.9.1/0.9.3.

INTEGRITE DE CETTE ARCHIVE
--------------------------
Build 15 = consolidation documentaire de la build 14 validee.

CoJGunslinger.exe SHA256 : b468197ddcba6547db8dda2efc3cd29f524f57992756aa813142b5531b2fd78d
coj4/Data0.pak SHA256    : ffa18821657e8f25063897a28730a03fb962abf22d572fb3d4fdd83772db0eab

Comparaison 15 vs 14 :
- EXE : strictement byte-for-byte identique ;
- Data0 : strictement byte-for-byte identique ;
- seul README.txt change.

PATCH COMBO/UPGRADED VALIDE (heritage build 13)
------------------------------------------------
- base historique : 0.9.2 ;
- B1D0F0 + test AL + saut vanilla : intacts ;
- seul le callsite B1B562 -> B1BD60 est filtre ;
- wrapper en .mod applique la vraie logique retail FloatingScoreVis + mode ;
- B1BD60 elle-meme reste intacte ;
- le filtre couvre visuel + son de la branche Upgraded validee en jeu.

PATCH HUD SCORE ARCADE VALIDE (build 14)
----------------------------------------
- routine ciblee : HudScoreBar a 0x00D75DE0 ;
- hook d'entree vers wrapper .mod 0x033A4D00 ;
- si FloatingScoreVis == 3 (Never/Off), branche vers le chemin vanilla Hide
  de HudScoreBar a 0x00D75E18 ;
- sinon reprise vanilla a 0x00D75DFA ;
- aucune modification de hud.xui pour cette fonction ;
- aucune interaction avec Duel/HudComboMessage/XP/subtitles.

DATA0
-----
- strictement identique aux builds 13/14 et a la base 0.9.2 correspondante ;
- 1774 entrees ;
- aucun repack supplementaire dans 13, 14 ou 15.

TESTS LIVE CONFIRMES POUR LA BASE STABLE
----------------------------------------
- build 13 : correctif Combo/Upgraded valide en jeu ;
- build 14 : HudScoreBar masque correctement en Arcade lorsque l'option est
  Never/Off, sans regression signalee sur le correctif build 13 ;
- build 15 : aucun changement binaire, donc aucun nouveau comportement a
  valider avant reprise du developpement.

============================================================================
4. CHRONOLOGIE DE REPRISE / POUR COMPRENDRE COMMENT ON EN EST ARRIVE LA
============================================================================

- V4/V5 : fondation Steam/ULC, qualite/LOD, switch clavier, premiers gains
  graphiques valides.
- V6/V7 : FOV/CRC/Developer Menu/inputs ; V7D puis V7K ont servi de bases
  importantes.
- V9G : chemin ForcedHorzFov natif valide, defaut 100 et plafond 120.
- V10A-M : probes viewmodel/FPP/legs/projection ; experimentaux, non integres.
  V10N redevient une base cumulative propre.
- V11 : nettoyage Weapon Trick / Drop Weapon, Walker, menus developer.
- V11X/V11Y : Weapon Trick/Drop Weapon puis Auto Reload valides.
- V11Z3 : Hold Reload -> Quick Reload valide au clavier ; gamepad reste TODO.
- V11Zxx : longue branche HUD. Plusieurs faux parents et transforms globaux ont
  ete elimines au profit de corrections locales.
- R01-R08 : nettoyage final HUD, comparaison contre le vrai Data0 retail,
  restauration des transforms fautifs et stabilisation des noms d'armes.
- 0.9.0 : meilleure base live validee.
- 0.9.1 : probe Combo/Upgraded REJETE, logique Upgraded active trop tot.
- 0.9.2 : re-gel de 0.9.0 avec README/audit hand-off complet ; BASE VALIDEE.
- 0.9.3 : probe bit d'etat HudComboMessage REJETE.
- 0.9.4 : architecture statiquement correcte retrouvee plus tard ; son principe
  devient la base du correctif Combo/Upgraded de la build 13.
- 0.9.5-0.9.12 : probes de diagnostic ; ne pas les utiliser comme bases.
- 13 : correctif Combo/Upgraded valide, gate vanilla conserve + filtre
  FloatingScoreVis/mode uniquement au callsite B1B562 -> B1BD60.
- 14 : ajoute le masquage valide de HudScoreBar en Arcade lorsque
  FloatingScoreVis = Never/Off.
- 15 : consolidation stable ; binaries strictement identiques a 14, README
  nettoye pour hand-off. Nouvelle base officielle de reprise.

Principe de reprise : repartir de 15. Une seule famille/systeme par build,
A/B en jeu, puis seulement integration dans la base suivante.

FIN DU README
=============
